import cv2
import numpy as py
import matplotlib.pyplot as pt

#img = cv2.imread("saroj.jpg",cv2.IMREAD_GRAYSCALE)
img1 = cv2.imread("saroj.jpg")
#img2 = cv2.imread("saroj.jpg",cv2.IMREAD_GRAYSCALE)
#cv2.imshow('image',img)
cv2.imshow('image',img1)
#cv2.imshow('image',img2)
cv2.waitKey(0)